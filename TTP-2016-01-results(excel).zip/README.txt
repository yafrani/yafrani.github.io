Experiment 1: large scale TTP algorithms
   MATLS vs MA2B vs CS2SA

Experiment 2: varying KP parameters
   All algorithms

Experiment 3: comparison of TTP algorithms
   All algorithms
